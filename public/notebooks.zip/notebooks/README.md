Jupyter notebook for MTH252:  
    
- lab1.ipynb
- lab2.ipynb
- lab3.ipynb
- lab4.ipynb
- lab5.ipynb
- lab6.ipynb